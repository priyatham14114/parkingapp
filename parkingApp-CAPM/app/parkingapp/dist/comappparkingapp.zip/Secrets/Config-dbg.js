
sap.ui.define([], function() {
    "use strict";
    return {
        twilio: {
            accountSid: 'AC0899939225d2307095a339d7ae171af4',
            authToken: '0ca8f811f586569b32edc1962d1a645f',
            fromNumber: '+15856485867'
        }
    };
});